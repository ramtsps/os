import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class RegistrationServlet extends HttpServlet {
 public void service(HttpServletRequest request, HttpServletResponse response) 
      throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    try {
        String url = "jdbc:mysql://localhost:3306/ram";
        String username = "root";
        String password = "";
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection(url, username, password);
        out.println(connection);
      
      Statement stmt = connection.createStatement();

      ResultSet rs=stmt.executeQuery("select * from product");
      while(rs.next()){
         out.println("<table>");
    out.println("<tr>");
    out.println("<th>no</th>");
    out.println("<th>product_name</th>");
    out.println("<th>description</th>");
    out.println("<th>price</th>");
    out.println("</tr>");
        out.println("<tr>");
        out.println("<td>");
        out.println(rs.getObject(1).toString());
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getObject(2).toString());
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getObject(3).toString());
        out.println("</td>");
        out.println("</tr>");
        out.println("<table>");
       
      }
    } catch (SQLException e) {
        String errorMessage = e.getMessage();
        out.println(errorMessage);
    } catch (ClassNotFoundException e) {
        String errorMessage = e.getMessage();
        out.println(errorMessage);
    }
    // rest of the code

  

        String fullName = request.getParameter("full-name");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phone-number");
        String address = request.getParameter("address");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String course = request.getParameter("course");
        String semester = request.getParameter("semester");
        String regFees = request.getParameter("registration-fees");

        out.println("<html>");
        out.println("<head><title>Registration Form Data</title></head>");
        out.println("<body>");
        out.println("<h1>Registration Form Data</h1>");
        out.println("<p>Name: " + fullName + "</p>");
        out.println("<p>Email: " + email + "</p>");
        out.println("<p>Phone Number: " + phoneNumber + "</p>");
        out.println("<p>Address: " + address + "</p>");
        out.println("<p>Date of Birth: " + dob + "</p>");
        out.println("<p>Gender: " + gender + "</p>");
        out.println("<p>Course: " + course + "</p>");
        out.println("<p>Semester: " + semester + "</p>");
        out.println("<p>Registration Fees: " + regFees + "</p>");
        out.println("</body></html>");

     

       
    }
}
