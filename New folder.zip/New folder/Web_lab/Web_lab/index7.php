<!-- CREATE TABLE info (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(30) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    email VARCHAR(50),
    phone VARCHAR(20),
    address VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(50),
    zip VARCHAR(10)
) -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="POST" action="index7.php">
    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" id="first_name" required>

    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" id="last_name" required>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email">

    <label for="phone">Phone:</label>
    <input type="tel" name="phone" id="phone">

    <label for="address">Address:</label>
    <input type="text" name="address" id="address">

    <label for="city">City:</label>
    <input type="text" name="city" id="city">

    <label for="state">State:</label>
    <input type="text" name="state" id="state">

    <label for="zip">Zip Code:</label>
    <input type="text" name="zip" id="zip">

    <button type="submit">Save</button>
</form>

</body>
</html>

<?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tspsram";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip'];

    // Insert the data into the database
    $sql = "INSERT INTO info (first_name, last_name, email, phone, address, city, state, zip)
            VALUES ('$first_name', '$last_name', '$email', '$phone
            '$address', '$city', '$state', '$zip')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>

<?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tsparam";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Select the data from the database
    $sql = "SELECT * FROM info";
    $result = $conn->query($sql);

    // Display the data in an HTML table
    if ($result->num_rows > 0) 
    {
        echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Phone</th><th>Address</th><th>City</th><th>State</th><th>Zip Code</th></tr>";

        while ($row = $result->fetch_assoc()) 
        {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["first_name"] . "</td><td>" . $row["last_name"] . "</td><td>" . $row["email"] . "</td><td>" . $row["phone"] . "</td><td>" . $row["address"] . "</td><td>" . $row["city"] . "</td><td>" . $row["state"] . "</td><td>" . $row["zip"] . "</td></tr>";
        }
         echo "</table>";
    } 
    
    else {
        echo "No results found";
    }

    // Close the database connection
    $conn->close();
?>