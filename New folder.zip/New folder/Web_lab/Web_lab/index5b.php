<!DOCTYPE html>
<html>
<head>
	<title>Session Tracking using Hidden Form Fields</title>
</head>
<body>
	<h1>Session Tracking using Hidden Form Fields</h1>
	<?php
		session_start();
		if(isset($_POST['submit'])){
			$_SESSION['name'] = $_POST['name'];
			$_SESSION['email'] = $_POST['email'];
			header('Location: index5c.html');
			exit();
		}
	?>
	<form action="" method="post">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name">
		<br>
		<label for="email">Email:</label>
		<input type="email" id="email" name="email">
		<br>
		<input type="submit" name="submit" value="Submit">
		<input type="hidden" name="PHPSESSID" value="<?php echo session_id(); ?>">
	</form>
</body>
</html>
