#include<stdio.h>
#include<conio.h>

int max[100][100];
int alloc[100][100];
int need[100][100];
int avail[100];
int n, r;

void input();
void show();
void cal();

int main() {
    printf("********** Deadlock Detection Algo ************\n");
    input();
    show();
    cal();
    getch();
    return 0;
}

void input() {
    int i, j;
    printf("Enter the no of Processes: ");
    scanf("%d", &n);
    printf("Enter the no of resource instances: ");
    scanf("%d", &r);

    printf("Enter the Max Matrix\n");
    for(i=0; i<n; i++) {
        for(j=0; j<r; j++) {
            scanf("%d", &max[i][j]);
        }
    }

    printf("Enter the Allocation Matrix\n");
    for(i=0; i<n; i++) {
        for(j=0; j<r; j++) {
            scanf("%d", &alloc[i][j]);
        }
    }

    printf("Enter the available Resources\n");
    for(j=0; j<r; j++) {
        scanf("%d", &avail[j]);
    }
}

void show() {
    int i, j;
    printf("\nProcess\tAllocation\tMax\tNeed\n");
    for(i=0; i<n; i++) {
        printf("P%d\t", i+1);
        for(j=0; j<r; j++) {
            printf("%d ", alloc[i][j]);
        }
        printf("\t");
        for(j=0; j<r; j++) {
            printf("%d ", max[i][j]);
        }
        printf("\t");
        for(j=0; j<r; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
}

void cal() {
    int finish[100] = {0};
    int dead[100], safe[100];
    int i, j, k, c1=0, flag=0;
    int avail_copy[100];
    int n_finish = 0;

    for(j=0; j<r; j++) {
        avail_copy[j] = avail[j];
    }

    while(n_finish < n) {
        flag = 0; //flag to check if any process can be allocated

        //check if a process can be allocated
        for(i=0; i<n; i++) {
            if(finish[i] == 0) { //if the process is not finished
                int c = 0;
                for(j=0; j<r; j++) {
                    if(need[i][j] <= avail_copy[j]) {
                        c++;
                    } else {
                        break;
                    }
                }
                if(c == r) { //if all resources can be allocated
                    for(j=0; j<r; j++) {
                        avail_copy[j] += alloc[i][j]; //add allocated resources to available
                    }
                    finish[i] = 1; //mark the process as finished
                    n_finish++; //increment the number of finished processes
                    safe[c1++] = i; //add the process to the safe sequence
                    flag = 1; //set the flag to true
                }
            }
        }
        if(flag == 0) { //if
//if no process can be allocated
        break; //exit the loop
    }
}

if(n_finish == n) { //if all processes finish
    printf("\nSystem is in a safe state\nSafe Sequence: ");
    for(i=0; i<n; i++) {
        printf("P%d ", safe[i]);
    }
} else { //if deadlock occurs
    printf("\nSystem is in deadlock\nDeadlock processes: ");
    for(i=0; i<n; i++) {
        if(finish[i] == 0) {
            printf("P%d ", i);
        }
    }
}
}