#include<stdio.h>
#include<stdlib.h>

struct rr {
    int pno, btime, sbtime, wtime, lst;
} p[10];

int main() {
    int pp=-1, ts, flag, count, ptm=0, i, n;
    printf("\n round robin scheduling............");
    printf("enter no of processes:");
    scanf("%d", &n);
    printf("enter the time slice:");
    scanf("%d", &ts);
    printf("enter the burst time");
    for(i=0; i<n; i++) {
        printf("\n process%d\t", i+1);
        scanf("%d", &p[i].btime);
        p[i].wtime = p[i].lst = 0;
        p[i].pno = i+1;
        p[i].sbtime = p[i].btime;
    }
    printf("scheduling....\n");
    do {
        flag = 0;
        for(i=0; i<n; i++) {
            if(p[i].btime > 0) {
                flag = -1;
                count = (p[i].btime >= ts) ? ts : p[i].btime;
                printf("\n process %d from %d to %d", p[i].pno, ptm, ptm+count);
                p[i].btime -= count;
                if(pp != i) {
                    pp = i;
                    p[i].wtime += ptm - p[i].lst - count;
                    p[i].lst = ptm;
                }
            }
        }
        ptm += count;
    } while(flag != 0);

    return 0;
}
