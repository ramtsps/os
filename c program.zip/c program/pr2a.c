#include<stdio.h>
#include<dirent.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
  char buff[100];
  DIR *dirp;
  printf("\n\nEnter directory name: ");
  scanf("%s", buff);
  if ((dirp = opendir(buff)) == NULL)
  {
    perror("The given directory does not exist");
    exit(1);
  }

  struct dirent *dptr;
  while ((dptr = readdir(dirp)) != NULL)
  {
    printf("%s\n", dptr->d_name);
  }

  closedir(dirp);
  return 0;
}
